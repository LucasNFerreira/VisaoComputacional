#!/usr/bin/env python

from twisted.web import server, resource
from twisted.internet import reactor, endpoints
from twisted.web.server import Site
from twisted.web.static import File
import json
import GraphData
import detector as dtc
import threading

data = GraphData.GraphData([['frame', 'luminance']])
dataGraph = 'data'

class Counter(resource.Resource):
    isLeaf = True
    numberRequests = 0

    def render_POST(self, request):
        self.numberRequests += 1
        request.setHeader(b"content-type", b"application/json")
        content = json.dumps({dataGraph: data.values})
        return content

def runServer(x):
    root = Counter()
    endpoints.serverFromString(reactor, "tcp:8000").listen(server.Site(root))
    resource = File('mean/')
    factory = Site(resource)
    reactor.listenTCP(8080, factory)
    reactor.run()

def runPageServer(x):
    resource = File('mean/')
    factory = Site(resource)
    reactor.listenTCP(8080, factory)
    reactor.run()

def runInParallel():
	t1 = threading.Thread(target = runServer, args = (0,))
	t1.start()

	t2 = threading.Thread(target = dtc.run, args = (data,))
	t2.start()

runInParallel()
