class GraphData(object):
    """docstring for GraphData"""

    name = 'Luminance'

    values = []

    def __init__(self, data):
        super (GraphData, self).__init__()
        self.values = data